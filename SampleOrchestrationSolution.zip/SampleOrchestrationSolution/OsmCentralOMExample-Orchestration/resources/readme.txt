This file is being use to ensure that all of the relevant resource zip files are created.
